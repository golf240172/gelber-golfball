Gelber Golfball – Android-Quellprojekt, Stand 20.10.2026

In Android Studio öffnen, Gradle synchronisieren und Build > Build APK(s) ausführen.
Noch keine fertige APK; Projekt hier nicht kompiliert oder auf einem Gerät getestet.
GPS-Standortabfrage ist implementiert. Entfernungsberechnung ist im Code vorbereitet, benötigt echte Golfplatz-Zielkoordinaten.
Scorekarte, Stableford, Handicap, Statistik, Offline-Platzdaten und automatische Locherkennung sind noch nicht implementiert.
