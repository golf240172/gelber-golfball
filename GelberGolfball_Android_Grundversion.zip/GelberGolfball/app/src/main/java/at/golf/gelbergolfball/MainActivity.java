package at.golf.gelbergolfball;
import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
public class MainActivity extends Activity {
  TextView gps, distance; LocationManager manager; LocationListener listener;
  // Demo-Zielkoordinate: erst nach Eingabe realer Platzdaten aktivieren.
  Double targetLat=null, targetLon=null;
  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    LinearLayout layout=new LinearLayout(this); layout.setOrientation(1);layout.setPadding(30,45,30,30);layout.setBackgroundColor(Color.rgb(237,247,229));
    TextView title=new TextView(this);title.setText("🟡 Gelber Golfball");title.setTextSize(27);title.setTextColor(Color.rgb(25,100,35));layout.addView(title);
    gps=new TextView(this);gps.setTextSize(19);gps.setText("GPS: Noch kein Standort");layout.addView(gps);
    distance=new TextView(this);distance.setTextSize(19);distance.setText("Grün / Bunker / Wasser: Platzdaten fehlen");layout.addView(distance);
    Button button=new Button(this);button.setText("GPS aktivieren");layout.addView(button);
    button.setOnClickListener(v->startGps());
    TextView note=new TextView(this);note.setText("\nGrundversion: Live-GPS-Position. Für genaue Golfentfernungen werden gespeicherte Koordinaten der Grüns und Hindernisse benötigt.\n\nWeitere Funktionen folgen: Scorekarte, Stableford, Handicap, Statistik, Offline-Plätze.");layout.addView(note);
    setContentView(layout);
  }
  void startGps() {
    if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) {
      requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},101);return;
    }
    manager=(LocationManager)getSystemService(LOCATION_SERVICE);
    listener=new LocationListener() { @Override public void onLocationChanged(Location l) {
      gps.setText(String.format(java.util.Locale.GERMANY,"GPS aktiv: %.6f, %.6f (± %.0f m)",l.getLatitude(),l.getLongitude(),l.getAccuracy()));
      if(targetLat!=null && targetLon!=null){float[] result=new float[1];Location.distanceBetween(l.getLatitude(),l.getLongitude(),targetLat,targetLon,result);distance.setText(String.format(java.util.Locale.GERMANY,"Ziel: %.0f m",result[0]));}
    }};
    try {manager.requestLocationUpdates(LocationManager.GPS_PROVIDER,2000,2f,listener);gps.setText("GPS sucht Satelliten …");}
    catch(Exception e){gps.setText("GPS nicht verfügbar: "+e.getMessage());}
  }
  @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==101&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startGps();}
  @Override protected void onDestroy(){super.onDestroy();if(manager!=null&&listener!=null)manager.removeUpdates(listener);}
}